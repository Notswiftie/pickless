import { MouseEvent } from "../BloomCore/utils/Utils"
import Dungeon from "../BloomCore/dungeons/Dungeon"

function aDungeon() { return Dungeon.inDungeon }

register(MouseEvent, (event) => {
    if (!aDungeon()) {
        const button = event.button;
        const state = event.buttonstate;

        if (button === 0 && state) {
            const heldItem = Player.getHeldItem();
            if (heldItem) {
                const heldItemName = heldItem.getName();
                if (heldItemName.includes("Pickonimbus")) {
                    ChatLib.chat('&r&eYou tried to &r&abreak blocks&r&e! &r&cStop that.');
                    cancel(event);
                }
            }
        }
    }
});

